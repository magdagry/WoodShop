<?php
/**
 * This file can be overridden by copying it to yourtheme/elementor-custom/product-search/view.php
 * 
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Metro_Core;
?>
<div class="rt-el-product-search">
	<?php get_template_part( 'template-parts/header/header-search2' );?>
</div>