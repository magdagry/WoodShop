<?php
namespace Rtwpvsp\Controllers\Admin\Meta;

class MetaOptions {  
    function __construct() {
        // tab option filter  
    }    
}