<?php

echo "Keep Silent";